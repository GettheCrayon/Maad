﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","hu",{title:"Helytartó beállítások",toolbar:"Helytartó készítése",name:"Helytartó neve",invalidName:"A helytartó nem lehet üres, és nem tartalmazhatja a következő karaktereket:[, ], <, > ",pathName:"helytartó"});